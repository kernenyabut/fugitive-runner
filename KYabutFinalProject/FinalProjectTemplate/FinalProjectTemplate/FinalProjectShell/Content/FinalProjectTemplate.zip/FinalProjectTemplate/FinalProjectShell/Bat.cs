﻿
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace FinalProjectShell
{
    public class Bat : DrawableGameComponent
    {
        

        private Texture2D texture;
        private Vector2 position;
        private Vector2 speed;

        public Bat(Game game): base(game)
        {
                     
            speed = new Vector2(4, 0);
        }

        public override void Update(GameTime gameTime)
        {
            KeyboardState ks = Keyboard.GetState();
            if (ks.IsKeyDown(Keys.Right))
            {
                position += speed;
            }
            else if (ks.IsKeyDown(Keys.Left))
            {
                position -= speed;                
            }
            // here we make sure that we are not off screen, we
            // clap the value to between 0 and width of screen - texture width
            position.X = MathHelper.Clamp(position.X, 0, GraphicsDevice.Viewport.Width - texture.Width);

            base.Update(gameTime);
        }

        public override void Draw(GameTime gameTime)
        {
            SpriteBatch sb = Game.Services.GetService<SpriteBatch>();

            sb.Begin();
            sb.Draw(texture, position, Color.White);
            sb.End();

            base.Draw(gameTime);
        }

        protected override void LoadContent()
        {
            texture = Game.Content.Load<Texture2D>("Images/Bat");

            // position our object at bottom center of screen
            position = new Vector2(GraphicsDevice.Viewport.Width / 2 - texture.Width / 2,
                                    GraphicsDevice.Viewport.Height - texture.Height);
            
            base.LoadContent();
        }
    }

}
